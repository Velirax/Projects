﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public abstract class HeroCreator
    {
        public abstract BaseHero CreateHero();

    }
}
